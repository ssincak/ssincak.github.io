<?php
    $db = mysql_connect(':/tmp/mysql51.sock', 'bubblik_usr', 'bubblik_pwd') or die('Could not connect: ' . mysql_error()); 
    mysql_select_db('bubblik_db') or die('Could not select database');

	// Strings must be escaped to prevent SQL injection attack. 
	$name = mysql_real_escape_string($_GET['name'], $db); 
	
	// get player score
	$query = "SELECT * FROM `scores` WHERE name = '" . $name . "' ORDER by `score` DESC LIMIT 1";
	$result = mysql_query($query) or die('Query failed: ' . mysql_error());
	
	$num_results = mysql_num_rows($result);  
	//echo "Displaying results (" . $num_results . ") for player: " . $name . "\n";
    for($i = 0; $i < $num_results; $i++)
    {
         $row = mysql_fetch_array($result);
		 
		 // get rank
		 $query = "SELECT 
					(SELECT COUNT(*)+1 FROM scores WHERE score > " . $row['score'] . ") as rank
				FROM
					 scores t";

		$result = mysql_query($query) or die('Query failed: ' . mysql_error());
		$rank = mysql_fetch_assoc($result);
		
		echo $rank['rank'] . ":" . $row['score'];
	}
?>