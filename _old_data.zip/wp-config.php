<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'kp_wordpress_db');

/** MySQL database username */
define('DB_USER', 'KnightPista');

/** MySQL database password */
define('DB_PASSWORD', 'wd98k2po');

/** MySQL hostname */
define('DB_HOST', ':/tmp/mysql51.sock');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'TU?<I;=Y|{dR|1|eUNM6^`K(ZI%u[TvJA,m*Js{<a;!i8M%6|w41|({=i7lHm2-V');
define('SECURE_AUTH_KEY',  '7(T/w(fI+4r28r#-X5pT+}QYa #{4?;o4Au/soiA0o%^C0=6G7_*Z~? +WwkAqG.');
define('LOGGED_IN_KEY',    '(Zg6&a8|hw|/EeS<#6{Re+.i#O]; UQ)mda=D9jp Krp{%t_|.2{Pzu3R]5NNuq^');
define('NONCE_KEY',        '_1~^sz#11~H-F.T +rD7{]4 dOg?Y_7ip?Py7>ck$WfDb[csq?5)32>9m|;?$p6;');
define('AUTH_SALT',        '=ckgC|t+ O&X&zwh`/B97-rkH1FT,kSxy@]$8 S.#uZ~Li5Q&p ^D/%f~<zJ^|,+');
define('SECURE_AUTH_SALT', '~>{^t+)KH1;t{) HJ(Y5U++|UWdKw?Ik{XT-g}<(9_;a4KU?9.|bhCnw0-M<Cn)4');
define('LOGGED_IN_SALT',   'u3 HM|@_N2v(2VvSD?lO|H<@Arw4y+cM(d7>RHS^q^9i3*L+$Z-2};i 8wd.-3%J');
define('NONCE_SALT',       '-A0-}fKBx,S7?PH^|}h:$i:it0S^Q=Kua79H 1<{`}DTHxO2L&y5Jv|U(z5,:7K[');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
